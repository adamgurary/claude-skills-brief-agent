# This week in Claude Code skills & plugins

_Brief generated 2026-09-27_

## Notable projects and releases
- **[reverse-skill](https://github.com/zhaoxuya520/reverse-skill)**, security research skill router for repeatable reverse-engineering and authorized pentesting workflows.
- **[Claude Code Router](https://github.com/musistudio/claude-code-router)**, local control plane for routing coding agents across models, tools, and providers.
- **[AI Website Cloner Template](https://github.com/JCodesMore/ai-website-cloner-template)**, `/clone-website` skill that recreates sites as Next.js apps.
- **[Huashu Design](https://github.com/alchaincyf/huashu-design)**, HTML-native design skill for prototypes, slides, animations, and design reviews.
- **[Humanizer-zh](https://github.com/op7418/Humanizer-zh)**, Chinese writing-editing skill that preserves facts, uncertainty, and author voice.
- **[ego lite](https://github.com/citrolabs/ego-lite)**, shared browser and `ego-browser` skill for agent web automation in isolated spaces.
- **[AI Berkshire](https://github.com/xbtlin/ai-berkshire)**, Claude Code and Codex skills for structured value-investing research.
- **[Claude Code Tips](https://github.com/ykdojo/claude-code-tips)**, 45+ workflow tips, plus the dx plugin for everyday development skills.

## Also worth a look
- **[sepia](https://github.com/Nanako0129/sepia)**, de-AI writing skill with a native Claude Code plugin.
- **[claude-code-skills-zh](https://github.com/laolaoshiren/claude-code-skills-zh)**, curated and original Skills, Agents, and Plugins for Chinese developers.
- **[Claude GRC Engineering](https://github.com/GRCEngClub/claude-grc-engineering)**, plugins for evidence collection, framework gap reports, and OSCAL workflows.
- **[chess-postmortem-skills](https://github.com/brumar/chess-postmortem-skills)**, a Claude Code skill for analyzing chess games.
