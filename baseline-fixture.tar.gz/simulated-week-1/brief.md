# This week in Claude Code skills & plugins

_Brief generated 2026-08-30_

## Notable projects and releases
- **[Claude Code Skills](https://github.com/alirezarezvani/claude-skills)**, a 388-skill, cross-agent library spanning engineering, research, security, and operations.
- **[Prompt Master](https://github.com/nidhinjs/prompt-master)**, a Claude skill for creating concise, tool-specific prompts.
- **[Social Media Research Skills](https://github.com/ScrapeCreators/social-media-research-skills)**, agent workflows for social research, comment mining, competitors, ads, and trends.
- **[Claude-OSINT](https://github.com/elementalsouls/Claude-OSINT)**, eight skills for authorized external reconnaissance and bug-bounty work.
- **[ClaudePrism](https://github.com/delibae/claude-prism)**, an offline-first scientific writing workspace with LaTeX, Python, and 100+ skills.
- **[Context Engineering Kit](https://github.com/NeoLabHQ/context-engineering-kit)**, token-efficient plugins and patterns for more predictable agent output.
- **[Claude Workflow v2](https://github.com/CloudAI-X/claude-workflow-v2)**, a universal workflow plugin with agents, commands, skills, and hooks.
- **[Agent Vision Toolkit](https://github.com/Anionex/agent-vision-toolkit)**, vision tools and a skill for image Q&A, OCR, UI restoration, and GUI automation.

## Also worth a look
- **[Claude marketplace](https://github.com/HexRaysSA/claude-marketplace)**, IDA plugins for Claude Code.
- **[Go Guidelines](https://github.com/mhmtszr/go-guidelines)**, version-aware production Go guidance for coding agents.
- **[Claude Kit](https://github.com/yeswehack/claude-kit)**, a plugin for triager-grade bug-bounty reports.
- **[Kindle highlights skill](https://github.com/l3a0/claude-plugins)**, a Claude Code skill for recovering export-blocked Kindle highlights.
