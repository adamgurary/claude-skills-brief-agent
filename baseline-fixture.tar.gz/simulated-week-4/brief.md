# This week in Claude Code skills & plugins

_Brief generated 2026-09-20_

## Notable projects and releases
- **[Ponytail](https://github.com/DietrichGebert/ponytail)**, a skill for minimal, safety-conscious code changes.
- **[Vibe Kanban](https://github.com/BloopAI/vibe-kanban)**, kanban planning and agent workspaces, now sunsetting.
- **[opcode](https://github.com/winfunc/opcode)**, desktop GUI for Claude Code sessions, agents, usage, and MCP servers.
- **[HTML Anything](https://github.com/nexu-io/html-anything)**, agentic HTML editor with 75 skill templates across nine output formats.
- **[fast-jev-compaction](https://github.com/tamaratran/fast-jev-compaction)**, Claude Code context compaction that preserves selected content verbatim.
- **[Agent Skills](https://github.com/tech-leads-club/agent-skills)**, security-focused validated skill registry for Claude Code and other agents.
- **[n8n-skills](https://github.com/czlonkowski/n8n-skills)**, 14 Claude Code skills for building and validating n8n workflows.
- **[darwin-skill](https://github.com/alchaincyf/darwin-skill)**, evaluate, improve, test, keep, or revert skill optimizations.

## Also worth a look
- **[smart-ralph](https://github.com/tzachbon/smart-ralph)**, spec-driven Claude Code development with structured compaction.
- **[Claudest](https://github.com/gupsammy/Claudest)**, opinionated marketplace for Claude Code skills and tools.
- **[superpowers-symfony](https://github.com/dev-toolings/superpowers-symfony)**, Symfony plugin with skills, subagents, and commands.
- **[ring](https://github.com/LerianStudio/ring)**, Claude Code marketplace with engineering-practice skills and specialized agents.
