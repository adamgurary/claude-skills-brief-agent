# This week in Claude Code skills & plugins

_Brief generated 2026-09-06_

## Notable projects and releases
- **[OpenMontage](https://github.com/calesthio/OpenMontage)**. Agentic video production system with research, editing, and rendering workflows.
- **[Anthropic Cybersecurity Skills](https://github.com/mukul975/Anthropic-Cybersecurity-Skills)**. Large security skill library mapped to six industry frameworks.
- **[Product Manager Skills](https://github.com/deanpeters/Product-Manager-Skills)**. Battle-tested product management frameworks for Claude Code and other agents.
- **[dev-browser](https://github.com/SawyerHood/dev-browser)**. Claude skill for persistent Chrome control through short JavaScript scripts.
- **[unlazy](https://github.com/Leonxlnx/unlazy)**. Completion-discipline skill using acceptance ledgers and runnable verification gates.
- **[Conductor](https://github.com/gemini-cli-extensions/conductor)**. Claude Code plugin for spec-driven development, planning, and managed project context.
- **[chinese-novelist-skill](https://github.com/PenglongHuang/chinese-novelist-skill)**. Chinese novel-writing skill with preference memory, continuation, and validation.
- **[claudex-loop](https://github.com/chaseai-yt/claudex-loop)**. Cross-provider workflow for plan review, implementation, and independent inspection.

## Also worth a look
- **[mcp-unity](https://github.com/CoderGamester/mcp-unity)**. MCP plugin connecting coding agents to the Unity Editor.
- **[vibe-coding-toolkit](https://github.com/soumatheusgomes/vibe-coding-toolkit)**. Production-oriented Claude Code plugins, orchestration patterns, and quality gates.
- **[modularity](https://github.com/vladikk/modularity)**. Claude Code plugin for modular-system design and codebase reviews.
- **[context-engineering-kit](https://github.com/NeoLabHQ/context-engineering-kit)**. Claude Code skills for advanced context-engineering techniques and patterns.
