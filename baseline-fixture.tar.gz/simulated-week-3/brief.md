# This week in Claude Code skills & plugins

_Brief generated 2026-09-13_

## Notable projects and releases
- **[AionUi](https://github.com/iOfficeAI/AionUi)**, open-source cowork app for Claude Code and other CLI agents.
- **[NotebookLM Claude Code Skill](https://github.com/PleasePrompto/notebooklm-skill)**, source-grounded NotebookLM querying, now archived.
- **[PinMe](https://github.com/glitternetwork/pinme)**, one-command full-stack deployment CLI with an agent skill.
- **[Agent Rules Books](https://github.com/ciembor/agent-rules-books)**, software-engineering book rules and skills for Claude Code.
- **[CCPlugins](https://github.com/brennercruvinel/CCPlugins)**, curated professional Claude Code workflow commands.
- **[Excalidraw MCP Server](https://github.com/yctimlin/mcp_excalidraw)**, live editable diagram canvas skill, CLI, and MCP server.
- **[Superpowers Marketplace](https://github.com/obra/superpowers-marketplace)**, curated Claude Code plugins for workflows and productivity.
- **[n-skills](https://github.com/numman-ali/n-skills)**, cross-agent curated skill marketplace with Claude Code support.

## Also worth a look
- **[SkillDock](https://github.com/wanghuan9/skilldock)**, desktop manager for skills, MCP servers, and plugins.
- **[3dviz Pro Max](https://github.com/viettranx/3dviz-pro-max)**, Claude Code and Codex skill for creative 3D scenes.
- **[Developer Kit](https://github.com/giuseppe-trisciuoglio/developer-kit)**, spec-driven skills and workflows marketplace for agentic CLIs.
- **[Claude Read Aloud](https://github.com/MichaelPGifford/claude-read-aloud)**, read Claude replies aloud.
